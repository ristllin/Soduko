/*
 * Initialization.h
 *
 *  Created on: Dec 24, 2018
 *      Author: Roy Darnell
 */

#ifndef INITIALIZATION_H_
#define INITIALIZATION_H_

void initialize(int[9][9][2],int[9][9][2]);

#endif /* INITIALIZATION_H_ */
